import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vtr-beta-component',
  templateUrl: './beta-component.component.html',
  styleUrls: ['./beta-component.component.scss']
})
export class BetaComponentComponent implements OnInit {

  backarrow = '< ';
  constructor() { }

  ngOnInit() {
  }

}
