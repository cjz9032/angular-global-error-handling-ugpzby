export enum HardwareScanOverallResult {
	Incomplete,
	Passed,
	Failed,
	Warning,
	Error,
	Cancelled
}