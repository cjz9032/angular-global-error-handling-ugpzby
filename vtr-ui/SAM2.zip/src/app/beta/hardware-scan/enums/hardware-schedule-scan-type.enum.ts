export enum HardwareScheduleScanType {
    Quick,
    Full
}