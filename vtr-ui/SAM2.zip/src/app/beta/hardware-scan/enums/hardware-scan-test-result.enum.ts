export enum HardwareScanTestResult {
	NotStarted,
	InProgress,
	Pass,
	Fail,
	Warning,
	Cancelled,
	Na
}
