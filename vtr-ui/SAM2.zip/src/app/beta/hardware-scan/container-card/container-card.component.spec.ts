import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContainerCardComponent } from './container-card.component';

xdescribe('ContainerCardComponent', () => {
	let component: ContainerCardComponent;
	let fixture: ComponentFixture<ContainerCardComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ContainerCardComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ContainerCardComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
