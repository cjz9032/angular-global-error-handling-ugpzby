import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayColorTempComponent } from './display-color-temp.component';

xdescribe('DisplayColorTempComponent', () => {
	let component: DisplayColorTempComponent;
	let fixture: ComponentFixture<DisplayColorTempComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DisplayColorTempComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DisplayColorTempComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
