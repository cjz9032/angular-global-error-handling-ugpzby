import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EyeCareModeComponent } from './eye-care-mode.component';

xdescribe('EyeCareModeComponent', () => {
	let component: EyeCareModeComponent;
	let fixture: ComponentFixture<EyeCareModeComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [EyeCareModeComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(EyeCareModeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
