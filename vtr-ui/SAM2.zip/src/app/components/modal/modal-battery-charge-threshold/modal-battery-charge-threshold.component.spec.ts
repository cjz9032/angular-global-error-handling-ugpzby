import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalBatteryChargeThresholdComponent } from './modal-battery-charge-threshold.component';

xdescribe('ModalBatteryChargeThresholdComponent', () => {
	let component: ModalBatteryChargeThresholdComponent;
	let fixture: ComponentFixture<ModalBatteryChargeThresholdComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ModalBatteryChargeThresholdComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ModalBatteryChargeThresholdComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
