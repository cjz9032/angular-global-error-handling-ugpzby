import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalWifiSecurityInvitationComponent } from './modal-wifi-security-invitation.component';

describe('ModalWifiSecurityInvitationComponent', () => {
	// let component: ModalWifiSecurityInvitationComponent;
	// let fixture: ComponentFixture<ModalWifiSecurityInvitationComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		// 	declarations: [ModalWifiSecurityInvitationComponent]
		// })
		// 	.compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(ModalWifiSecurityInvitationComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
