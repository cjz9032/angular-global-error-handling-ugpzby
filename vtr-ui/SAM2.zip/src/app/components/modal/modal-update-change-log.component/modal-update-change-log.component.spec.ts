import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalUpdateChangeLogComponent } from './modal-update-change-log.component';

describe('UpdateChangeLogComponent', () => {
	// let component: ModalUpdateChangeLogComponent;
	// let fixture: ComponentFixture<ModalUpdateChangeLogComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		// 	declarations: [ModalUpdateChangeLogComponent]
		// })
		// 	.compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(ModalUpdateChangeLogComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
