import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalFindUsComponent } from './modal-find-us.component';

describe('ModalFindUsComponent', () => {
	//   let component: ModalFindUsComponent;
	//   let fixture: ComponentFixture<ModalFindUsComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		//   declarations: [ ModalFindUsComponent ]
		// })
		// .compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(ModalFindUsComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
