import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalThreatLocatorComponent } from './modal-threat-locator.component';

describe('ModalThreatLocatorComponent', () => {
	// let component: ModalThreatLocatorComponent;
	// let fixture: ComponentFixture<ModalThreatLocatorComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		// 	declarations: [ModalThreatLocatorComponent]
		// })
		// 	.compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(ModalThreatLocatorComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
