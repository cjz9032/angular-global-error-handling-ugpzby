import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalVoiceComponent } from './modal-voice.component';

describe('ModalVoiceComponent', () => {
//   let component: ModalVoiceComponent;
//   let fixture: ComponentFixture<ModalVoiceComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ ModalVoiceComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(ModalVoiceComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
