import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalLenovoIdComponent } from './modal-lenovo-id.component';

xdescribe('ModalLenovoIdComponent', () => {
	let component: ModalLenovoIdComponent;
	let fixture: ComponentFixture<ModalLenovoIdComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ModalLenovoIdComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ModalLenovoIdComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
