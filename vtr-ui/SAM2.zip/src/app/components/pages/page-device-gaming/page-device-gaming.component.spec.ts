import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageDeviceGamingComponent } from './page-device-gaming.component';

xdescribe('PageDeviceGamingComponent', () => {
	let component: PageDeviceGamingComponent;
	let fixture: ComponentFixture<PageDeviceGamingComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [PageDeviceGamingComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PageDeviceGamingComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
