import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vtr-page-hardwarescan',
  templateUrl: './page-hardwarescan.component.html',
  styleUrls: ['./page-hardwarescan.component.scss']
})
export class PageHardwarescanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
