import { TestBed } from '@angular/core/testing';

import { NavTabsService } from './nav-tabs.service';

describe('NavTabsService', () => {
  //beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    // const service: NavTabsService = TestBed.get(NavTabsService);
    // expect(service).toBeTruthy();
  });
});
