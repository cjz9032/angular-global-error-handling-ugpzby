import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TryProductBlockComponent } from './try-product-block.component';

describe('TryProductBlockComponent', () => {
  // let component: TryProductBlockComponent;
  // let fixture: ComponentFixture<TryProductBlockComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ TryProductBlockComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(TryProductBlockComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
