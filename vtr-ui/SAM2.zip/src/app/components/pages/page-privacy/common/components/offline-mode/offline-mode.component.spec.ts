import { OfflineModeComponent } from './offline-mode.component';

describe('OfflineModeComponent', () => {
	// it('should create an instance', () => {
	// 	const directive = new OfflineModeComponent();
	// 	expect(directive).toBeTruthy();
	// });
});
