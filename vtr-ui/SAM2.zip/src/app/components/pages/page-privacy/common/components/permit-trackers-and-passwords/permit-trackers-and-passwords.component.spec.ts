import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitTrackersAndPasswordsComponent } from './permit-trackers-and-passwords.component';

describe('PermitTrackersAndPasswordsComponent', () => {
	// let component: PermitTrackersAndPasswordsComponent;
	// let fixture: ComponentFixture<PermitTrackersAndPasswordsComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		// 	declarations: [PermitTrackersAndPasswordsComponent]
		// })
		// 	.compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(PermitTrackersAndPasswordsComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
