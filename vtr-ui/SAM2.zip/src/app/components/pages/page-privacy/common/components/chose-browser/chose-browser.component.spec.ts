import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoseBrowserComponent } from './chose-browser.component';

describe('ChoseBrowserComponent', () => {
  // let component: ChoseBrowserComponent;
  // let fixture: ComponentFixture<ChoseBrowserComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ ChoseBrowserComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(ChoseBrowserComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
