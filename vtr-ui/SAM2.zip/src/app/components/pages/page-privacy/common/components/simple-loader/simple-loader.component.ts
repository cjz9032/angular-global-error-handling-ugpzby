import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'vtr-simple-loader',
	templateUrl: './simple-loader.component.html',
	styleUrls: ['./simple-loader.component.scss']
})
export class SimpleLoaderComponent implements OnInit {

	constructor() {
	}

	ngOnInit() {
	}

}
