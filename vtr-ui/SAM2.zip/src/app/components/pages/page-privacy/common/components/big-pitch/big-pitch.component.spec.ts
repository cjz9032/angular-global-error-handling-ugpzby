import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BigPitchComponent } from './big-pitch.component';

describe('BigPitchComponent', () => {
  // let component: BigPitchComponent;
  // let fixture: ComponentFixture<BigPitchComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ BigPitchComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(BigPitchComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
