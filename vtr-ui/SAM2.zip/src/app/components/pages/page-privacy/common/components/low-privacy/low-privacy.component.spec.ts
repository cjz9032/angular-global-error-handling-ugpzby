import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LowPrivacyComponent } from './low-privacy.component';

describe('LowPrivacyComponent', () => {
  // let component: LowPrivacyComponent;
  // let fixture: ComponentFixture<LowPrivacyComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ LowPrivacyComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(LowPrivacyComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
