import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDefinedKeyComponent } from './user-defined-key.component';

describe('UserDefinedKeyComponent', () => {
  // let component: UserDefinedKeyComponent;
  // let fixture: ComponentFixture<UserDefinedKeyComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ UserDefinedKeyComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(UserDefinedKeyComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
  //   expect(component).toBeTruthy();
  });
});
