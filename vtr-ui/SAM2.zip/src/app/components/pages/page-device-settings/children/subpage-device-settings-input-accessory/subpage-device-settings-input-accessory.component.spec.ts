import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubpageDeviceSettingsInputAccessoryComponent } from './subpage-device-settings-input-accessory.component';

xdescribe('SubpageDeviceSettingsInputAccessoryComponent', () => {
  let component: SubpageDeviceSettingsInputAccessoryComponent;
  let fixture: ComponentFixture<SubpageDeviceSettingsInputAccessoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubpageDeviceSettingsInputAccessoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubpageDeviceSettingsInputAccessoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
