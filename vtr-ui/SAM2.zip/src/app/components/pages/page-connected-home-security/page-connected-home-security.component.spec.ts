import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageConnectedHomeSecurityComponent } from './page-connected-home-security.component';

describe('PageConnectedHomeSecurityComponent', () => {
  // let component: PageConnectedHomeSecurityComponent;
  // let fixture: ComponentFixture<PageConnectedHomeSecurityComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ PageConnectedHomeSecurityComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(PageConnectedHomeSecurityComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
