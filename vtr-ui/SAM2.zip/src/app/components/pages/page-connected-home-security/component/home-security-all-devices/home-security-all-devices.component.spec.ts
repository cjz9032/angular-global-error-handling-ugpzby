import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeSecurityAllDevicesComponent } from './home-security-all-devices.component';

describe('HomeSecurityAllDevicesComponent', () => {
	// let component: HomeSecurityAllDevicesComponent;
	// let fixture: ComponentFixture<HomeSecurityAllDevicesComponent>;

	beforeEach(async(() => {
		// TestBed.configureTestingModule({
		// 	declarations: [ HomeSecurityAllDevicesComponent ]
		// })
		// .compileComponents();
	}));

	beforeEach(() => {
		// fixture = TestBed.createComponent(HomeSecurityAllDevicesComponent);
		// component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it('should create', () => {
		// expect(component).toBeTruthy();
	});
});
