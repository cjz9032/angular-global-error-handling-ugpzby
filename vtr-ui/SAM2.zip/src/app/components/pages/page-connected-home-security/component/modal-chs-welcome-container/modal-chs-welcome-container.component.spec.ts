import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalChsWelcomeContainerComponent } from './modal-chs-welcome-container.component';

describe('ModalChsWelcomeContainerComponent', () => {
  // let component: ModalChsWelcomeContainerComponent;
  // let fixture: ComponentFixture<ModalChsWelcomeContainerComponent>;

  beforeEach(async(() => {
    // TestBed.configureTestingModule({
    //   declarations: [ ModalChsWelcomeContainerComponent ]
    // })
    // .compileComponents();
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(ModalChsWelcomeContainerComponent);
    // component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
