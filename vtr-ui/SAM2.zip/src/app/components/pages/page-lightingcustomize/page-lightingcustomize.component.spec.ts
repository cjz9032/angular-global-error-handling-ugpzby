import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageLightingcustomizeComponent } from './page-lightingcustomize.component';

xdescribe('PageLightingcustomizeComponent', () => {
	let component: PageLightingcustomizeComponent;
	let fixture: ComponentFixture<PageLightingcustomizeComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [PageLightingcustomizeComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PageLightingcustomizeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
