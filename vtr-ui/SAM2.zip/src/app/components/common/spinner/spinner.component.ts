import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'vtr-spinner',
	templateUrl: './spinner.component.html',
	styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {

	@Input() className = 'spinner';

	constructor() { }

	ngOnInit() {
	}

}
